/*
 *  hellojniPriv.h
 *  hellojni
 *
 *  Created by Ling Xiao on 14-9-4.
 *  Copyright (c) 2014年 Dynamsoft. All rights reserved.
 *
 */

/* The classes below are not exported */
#pragma GCC visibility push(hidden)

class hellojniPriv
{
	public:
		void HelloWorldPriv(const char *);
};

#pragma GCC visibility pop
