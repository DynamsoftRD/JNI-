/*
 *  hellojni.h
 *  hellojni
 *
 *  Created by Ling Xiao on 14-9-4.
 *  Copyright (c) 2014年 Dynamsoft. All rights reserved.
 *
 */

#ifndef hellojni_
#define hellojni_

/* The classes below are exported */
#pragma GCC visibility push(default)

class hellojni
{
	public:
		void HelloWorld(const char *);
};

#pragma GCC visibility pop
#endif
